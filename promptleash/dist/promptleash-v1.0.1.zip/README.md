# AI 训狗器 (PromptLeash)

**把上下文带走，把回答拉回正题。** Chrome / Edge Manifest V3 扩展，中文界面，纯本地运行。

原创深绿对话框 + 勾选图标，不使用任何 AI 平台标志。本项目独立开发，与 OpenAI、Anthropic、Google、Microsoft 均无隶属或合作关系。

**验证状态：ChatGPT 已通过真实站点验证；Claude.ai 支持已实现，但待实测（仅通过隔离夹具测试，尚未在真实站点验证）。**

## 功能

- **交接卡**：从当前页面已加载的对话中，用本地规则提取「目标 / 已定决策 / 禁止事项」。目标从前两条用户消息提取，去掉已分类的决策/禁令与纯回复格式指令，去标签、去重，最多 400 字。可编辑、复制，或带去新对话。新页只填入，不自动发送。待交接内容按站点分开，最多保留五分钟，成功插入后删除；已有草稿时不覆盖。
- **一键纠偏**：偏题重来、太长精简、直接给结果、别瞎编、按我的要求重做。默认填入后发送，可在弹窗改为「只填入不发送」。输入框已有草稿时拒绝覆盖。
- **防废话模式**：拦截输入框的普通 Enter 和发送按钮点击，发送前追加一次回答要求。默认 300 字，可设为 50–5000 字。Shift+Enter、输入法组字中的 Enter 不拦截。
- **悬浮面板**：Shadow DOM 隔离样式，可折叠，拖动标题移动并记住位置；弹窗可隐藏面板（防废话仍可独立启用）。
- 所有设置仅保存于当前浏览器设备，不同步。

## 安装：Chrome 与 Edge

1. 下载并解压 `dist/promptleash-v1.0.1.zip` 至固定目录，或直接使用本仓库根目录。
2. Chrome 打开 `chrome://extensions`；Edge 打开 `edge://extensions`。
3. 开启「开发者模式」，选择「加载已解压的扩展程序」，选中含 `manifest.json` 的目录。
4. 在工具栏扩展菜单固定「AI 训狗器 (PromptLeash)」。打开或刷新 ChatGPT / Claude 页面，点击右下角胶囊。
5. 工具栏图标打开设置。更新源码后，在扩展管理页重新加载扩展，再刷新站点。

匹配范围：`https://chatgpt.com/*`、`https://chat.openai.com/*`、`https://claude.ai/*`。

## 使用示例

讨论中明确说「决定采用 CSV，不要联网」。点击「提取当前对话」，检查交接卡后点「带去新对话」。等待输入框出现，确认内容，再自己发送。

纠偏按钮是**给 AI 的新消息**，可能消耗站点额度。防废话字数属于提示要求，不是强制截断，也不能保证模型遵守；请检查真正发送的消息和回答。

## 隐私与权限

唯一权限为 `storage`；内容脚本仅注入上述三个站点。无后台服务、无 API Key、无分析、无外部网络请求、无远程脚本或字体。网站响应用户发送消息产生的正常网络流量不属于扩展请求。扩展不读取 Cookie 或登录凭据。

对话只在页面中本地读取、按需提取，未提取时不保存历史。仅当点击「带去新对话」时，交接卡文本会暂存于 `chrome.storage.local`，插入后删除；过期内容在下一次受支持页面初始化时清除（关闭浏览器时不会定时物理删除）。编辑预览仅保留在页面内存，刷新会丢失。设置与面板坐标会持久保存。卸载扩展可删除扩展本地存储。

发送和跨站点导航均需用户操作。不自动登录、不绕过站点访问限制。交接卡不会自动跨 ChatGPT / Claude 迁移；跨站点可手动复制。

## 限制与兼容性

- 提取是关键词启发式，不是摘要模型，会误判、漏判、保留冲突或已被推翻的决策。决策和禁令主要来自用户；助手仅接受以「已确定 / 最终决定 / 我们已决定 / we decided」开头且不含问号的明确确认，并排除超过 500 字或 8 句的助手消息。只处理页面 DOM 中已加载的消息，不抓取隐藏历史；请先核对卡片。
- 站点可能更换选择器或发送逻辑。选择器及回退集中在 `adapters.js`。支持 ProseMirror；此次 ChatGPT 未登录实站出现新版 `textarea#mobile-composer-prompt`，也提供兼容。
- 发送按钮忙碌或不可用时最多等待三秒；不会强行发送，草稿保留。不要在此期间继续编辑或重复发送。站点快捷键、语音、其他扩展发消息等路径不保证覆盖。
- 未实现自动折叠长回答。Edge 复用 Chromium MV3 API，但本次未单独运行 Edge。
- Claude 登录在本次实站验证中受阻：提供的 Tuta 账户返回已停用，无法取得魔法链接。因此 Claude 的真实输入框/发送选择器及实际发送**尚未验证**；隔离测试不替代实站验证。详情见 `docs/verification.md`。

## 开发与打包

需要 Node.js 20+、Python 3；图标重新生成额外需要 Pillow。运行时无第三方依赖。

```sh
npm ci
npm test                # node:test 纯提取与规则单元测试
npm run test:e2e        # Playwright 加载未打包扩展，使用隔离站点夹具
npm run build          # dist/promptleash-v1.0.1.zip
```

`test:e2e` 默认使用本机 `/home/ubuntu/.local/bin/google-chrome`，其他机器可设置 `CHROME_PATH`。夹具通过 Playwright 路由本地响应，无真实 AI 请求；覆盖两个适配器、Enter/点击发送、规则去重、纠偏填入/发送、草稿保护、交接只消费一次/过期、面板隐藏与 DOM 重挂载。

文件结构沿用轻量扩展的 manifest + 内容脚本 + 弹窗 + 原创 PNG 图标 + Node 测试方式，未复制旧项目品牌或网络观察逻辑。

| 文件 | 职责 |
| --- | --- |
| `extract.js` | 可在 Node 运行的纯提取、规则函数 |
| `adapters.js` | 两站点 DOM 选择器、文本读取与插入 |
| `content.js` | 面板、发送拦截、交接生命周期 |
| `popup.*` | 本地设置 |
| `scripts/build.py` | 白名单打包，仅包含扩展运行文件、图标与 MIT 许可 |
| `tests/` | 单元与隔离浏览器测试 |
| `docs/` | 实站验证与截图证据 |

## English

PromptLeash is an independent, local-only Chrome/Edge MV3 extension for ChatGPT and Claude. It extracts editable handoff cards using heuristics, inserts corrective prompts, and optionally appends concise-answer rules before sending. Only the storage permission is requested. No API keys, analytics, external requests, or remotely hosted assets. Load the unpacked directory from Chrome/Edge's extensions page with Developer mode enabled. Review all extracted content before sending. Site DOM changes may break compatibility. Only ChatGPT has been verified live. Claude support is implemented but awaits real-site verification; fixture tests are not live-site evidence. MIT licensed.
